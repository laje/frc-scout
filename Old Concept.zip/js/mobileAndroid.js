if (window.matchMedia('(display-mode: standalone)').matches) {
  $('mobile-notification').addClass('hidden');
}
